-- Creo la base
--create Database BDConsumoGrifo;

-- Actualizo el a�ado las tablas

--use BDConsumoGrifo;

-- tabla 1 de facturacion, ser� el principal
create table Facturacion(
	numOperacion int primary key not null,
	DNI int, 
-- PK: son los cargadores (los que conectan), Foreign Key: son los enchufes (los que reciben)
	nombre varchar(50),
	Placa varchar(6) not null,
	Consumo_watts tinyint not null,
	SubTotal int not null,
	Descuento int,
	IGV numeric(10,2),
	total numeric (15,2)
)

-- tabla de identificaci�n del cliente
create table ID_cliente(
	numOperacion int primary key not null,
	DNI int, 
-- PK: son los cargadores (los que conectan), Foreign Key: son los enchufes (los que reciben)
	ruc tinyint,
	Razon_Social varchar(60), -- Debido a su complejidad de posibilidad de extensi�n
	Domicilio_Fiscal varchar (70)
)

-- tabla de ubicaci�n, para dar m�s detalle
create table Ubicacion(
	numOperacion int primary key not null,
	ciudad varchar(50), 
-- PK: son los cargadores (los que conectan), Foreign Key: son los enchufes (los que reciben)
	Nombre_Estacion varchar(50),
)