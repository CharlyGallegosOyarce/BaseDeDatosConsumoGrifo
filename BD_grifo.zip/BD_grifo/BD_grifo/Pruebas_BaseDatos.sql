
-- chequeo de las tablas
select*from Facturacion
select*from ID_cliente
select*from Ubicacion

-- proceso de obtenci�n de datos
CREATE PROCEDURE obtenerFacturaPorNumOperacion
    @numeroOperacion int
AS
BEGIN
    SELECT *
    FROM Facturacion 
    WHERE Facturacion.numOperacion=@numeroOperacion;
END;
-- aqu� ejecutamos para su ubicaci�n y mayor facilidad de ejecuci�n
exec obtenerFacturaPorNumOperacion @numeroOperacion= 00001;
-- a trav�s de una variable como @numeroOperacion, nos brinda mayor generalidad y podemos poner el valor que queremos buscar




